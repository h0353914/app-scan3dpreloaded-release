# This zip-file contains your 3D-model.

## Viewing locally

If you want to view the scan locally on your desktop, extract this zip-file to a folder.
Download meshlab [link](http://meshlab.sourceforge.net/), go to File->Import Mesh and
choose mesh.obj. In Render in the Menu you can experiment with different lighting and
rendering options.

## Sharing with friends

If you want to share the scan with your family and friends, you can register for free on
[link](https://sketchfab.com/). Once you have an account, you upload the entire zip-file.
You will be able to do some basic settings of how it should be shown (default rotation,
lighting, rendering options etc.) Then you can share the link to your friends. Note: it
will be public on the internet.
